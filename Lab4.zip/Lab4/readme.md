This files are dedicated for Bioinformatics lab4, to convert codons to amino acid sequences. 24 Oct 2025.

Contributor: Postelnecu Ioana

You could also find the screenshots of the each outputs. 